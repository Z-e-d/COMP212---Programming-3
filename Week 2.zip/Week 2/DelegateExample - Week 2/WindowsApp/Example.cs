﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp
{
    public partial class Example : Form
    {
        public Example()
        {
            InitializeComponent();
        }

        private void Example_Load(object sender, EventArgs e)
        {

        }

        //A simple property test 
        private void validateButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The button was clicked.");
        }

        //Event handler to display the hidden text within the password textbox
        private void displaypassButton_Click(object sender, EventArgs e)
        {
            displayPassTextBox.Text = passTextBox.Text;
        }
    }
}
