﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp
{
    static class Program
    {
        /*
         * To view the properties of a property (textbox,button etc) right click the property and click properties while in
         * design view. This will display multiple features that would allow you to manipulate that property. It will also
         * display the property's name which is very important when handling events or further manipulating that property.
         * To create an event handler method, simply double click the property while in design view.
         */
        
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Example());
        }
    }
}
