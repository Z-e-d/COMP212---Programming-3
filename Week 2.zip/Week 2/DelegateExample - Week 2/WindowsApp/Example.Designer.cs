﻿namespace WindowsApp
{
    partial class Example
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.validateBox = new System.Windows.Forms.Button();
            this.displaypassButton = new System.Windows.Forms.Button();
            this.displayPassTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // passTextBox
            // 
            this.passTextBox.Location = new System.Drawing.Point(141, 87);
            this.passTextBox.Name = "passTextBox";
            this.passTextBox.PasswordChar = '*';
            this.passTextBox.Size = new System.Drawing.Size(221, 22);
            this.passTextBox.TabIndex = 0;
            // 
            // validateBox
            // 
            this.validateBox.Location = new System.Drawing.Point(141, 12);
            this.validateBox.Name = "validateBox";
            this.validateBox.Size = new System.Drawing.Size(125, 57);
            this.validateBox.TabIndex = 1;
            this.validateBox.Text = "Click here to test property";
            this.validateBox.UseVisualStyleBackColor = true;
            this.validateBox.Click += new System.EventHandler(this.validateButton_Click);
            // 
            // displaypassButton
            // 
            this.displaypassButton.Location = new System.Drawing.Point(141, 143);
            this.displaypassButton.Name = "displaypassButton";
            this.displaypassButton.Size = new System.Drawing.Size(125, 57);
            this.displaypassButton.TabIndex = 2;
            this.displaypassButton.Text = "Display Password";
            this.displaypassButton.UseVisualStyleBackColor = true;
            this.displaypassButton.Click += new System.EventHandler(this.displaypassButton_Click);
            // 
            // displayPassTextBox
            // 
            this.displayPassTextBox.Location = new System.Drawing.Point(141, 115);
            this.displayPassTextBox.Name = "displayPassTextBox";
            this.displayPassTextBox.Size = new System.Drawing.Size(221, 22);
            this.displayPassTextBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Hidden Password: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Visible Password: ";
            // 
            // Example
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 217);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.displayPassTextBox);
            this.Controls.Add(this.displaypassButton);
            this.Controls.Add(this.validateBox);
            this.Controls.Add(this.passTextBox);
            this.Name = "Example";
            this.Text = "Property Tester";
            this.Load += new System.EventHandler(this.Example_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.Button validateBox;
        private System.Windows.Forms.Button displaypassButton;
        private System.Windows.Forms.TextBox displayPassTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

