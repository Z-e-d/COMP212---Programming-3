﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateExample___Week_2
{
    class Program
    {
        /*A lambda expression is an anonymous function that you can use to create delegates
        By using lambda expressions you can write local functions that can be passed as arguments 
        or returned as the value of function calls.*/

        private delegate int lambdaexample(int x);

        static void Main(string[] args)
        {
            //Prompting user for input
            Console.WriteLine("What number would you like to square?");
            int square = Convert.ToInt32(Console.ReadLine());

            //Using lambda
            lambdaexample example = x => x * x;
            Console.WriteLine("The result is {0}", example(square));
            Console.ReadKey();
        }
    }
}
